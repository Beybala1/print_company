
@extends('layouts.app_front')
@section('content')
    @include('inc.service')
@endsection
