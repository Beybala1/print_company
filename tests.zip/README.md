<h2>Print Company</h2>

1.Run git clone <my-cool-project>
    
2.Run composer install
    
3.Run cp .env.example .env
    
4.Run php artisan key:generate
    
5.Run php artisan migrate

6.Run php artisan db:seed

7.Run php artisan storage:link
    
8.Run php artisan serve
    
9.Go to link localhost:8000

<hr>

Packages:<br>
. https://realrashid.github.io/sweet-alert<br>
. https://github.com/mcamara/laravel-localization<br>
. https://github.com/spatie/laravel-permission<br>
